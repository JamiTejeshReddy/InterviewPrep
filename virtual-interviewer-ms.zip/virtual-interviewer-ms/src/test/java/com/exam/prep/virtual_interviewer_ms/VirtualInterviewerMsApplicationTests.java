package com.exam.prep.virtual_interviewer_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualInterviewerMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
