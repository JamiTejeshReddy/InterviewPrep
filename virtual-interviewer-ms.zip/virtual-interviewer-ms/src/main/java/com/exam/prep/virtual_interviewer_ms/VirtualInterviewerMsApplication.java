package com.exam.prep.virtual_interviewer_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtualInterviewerMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualInterviewerMsApplication.class, args);
	}

}
